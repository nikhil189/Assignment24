package accadglidassignment;

import java.io.IOException;
import java.util.Scanner;

public class PrintLargestNumber {

	public static void main(String ...K) throws IOException
	{
		try
		{
			int iLargest =0;
			Scanner objScanner = new Scanner(System.in);
			System.out.println("Enter First number");
			int arrNum[] = new int[3];
			arrNum[0] = objScanner.nextInt();
			System.out.println("Enter Second number");
			arrNum[1] = objScanner.nextInt();
			System.out.println("Enter Third number");
			arrNum[2] = objScanner.nextInt();
			objScanner.close();
			for(int iIndex =0; iIndex<arrNum.length-1;iIndex++)
			{
				if(arrNum[iIndex]<arrNum[iIndex+1])
				{
					iLargest = arrNum[iIndex+1];
				}
			}
			System.out.println("largest number is" + iLargest);
		}
		catch(Exception ex)
		{
			System.out.println("exception" + ex.getMessage());
		}
	}
}
